//+------------------------------------------------------------------+
//| KIRA Member Manual Receiver                                      |
//| Proprietary KIRA Engineer Hub material.                           |
//| Milestone 2B: manual-review receiver only.                        |
//+------------------------------------------------------------------+
#property copyright "KIRA Engineer Hub"
#property version   "0.2"
#property strict

input bool   EnablePolling    = false;
input string ApiEndpoint      = "";
input string SharedSecret     = "";
input string MemberId         = "";
input string BrokerAccountId  = "";
input string TerminalInstanceId = "mt5-member-terminal-1";
input int    PollSeconds      = 30;

string lastStatus = "Starting manual receiver...";

void DisplayStatus(string message)
{
   lastStatus = message;
   Comment(
      "KIRA Member Manual Receiver\n",
      "Mode: Manual review only\n",
      "Member: ", MemberId, "\n",
      "Account label: ", BrokerAccountId, "\n\n",
      "Terminal: ", TerminalInstanceId, "\n\n",
      message
   );
}

bool IsConfigured()
{
   return StringLen(ApiEndpoint) > 0
      && StringLen(SharedSecret) > 0
      && StringLen(MemberId) > 0
      && StringLen(BrokerAccountId) > 0
      && StringLen(TerminalInstanceId) > 0;
}

string BuildUrl()
{
   string baseUrl = ApiEndpoint;
   int baseLen = StringLen(baseUrl);
   if(baseLen > 0 && StringSubstr(baseUrl, baseLen - 1, 1) == "/")
      baseUrl = StringSubstr(baseUrl, 0, baseLen - 1);

   return baseUrl
      + "/v1/members/" + MemberId + "/copy-commands/pending"
      + "?format=mt5-text"
      + "&brokerAccountId=" + BrokerAccountId
      + "&terminalInstanceId=" + TerminalInstanceId;
}

string ClipForTerminal(string value, int limit)
{
   if(StringLen(value) <= limit)
      return value;

   return StringSubstr(value, 0, limit) + "...";
}

int OnInit()
{
   int seconds = MathMax(10, PollSeconds);
   EventSetTimer(seconds);
   DisplayStatus("Standby. Enable polling only after the API endpoint is ready.");
   Print("KIRA Member Manual Receiver loaded in manual-review mode.");
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   Comment("");
}

void OnTick()
{
   // Manual receiver is timer-driven; market ticks do not trigger actions.
}

void OnTimer()
{
   if(!EnablePolling)
   {
      DisplayStatus("Polling disabled. Waiting for KIRA Copy Engine setup.");
      return;
   }

   if(!IsConfigured())
   {
      DisplayStatus("Setup incomplete. Add endpoint, member ID, and secret.");
      return;
   }

   string url = BuildUrl();
   string headers =
      "X-KIRA-Member-Id: " + MemberId + "\r\n" +
      "X-KIRA-Broker-Account-Id: " + BrokerAccountId + "\r\n" +
      "X-KIRA-Terminal-Instance-Id: " + TerminalInstanceId + "\r\n" +
      "X-KIRA-Member-Secret: " + SharedSecret + "\r\n";

   char data[];
   char result[];
   string responseHeaders;

   ResetLastError();
   int responseCode = WebRequest("GET", url, headers, 5000, data, result, responseHeaders);
   int terminalError = GetLastError();

   if(responseCode == -1)
   {
      DisplayStatus(
         "Connection not allowed yet. Add the KIRA API URL in MT5: Tools > Options > Expert Advisors > Allow WebRequest."
      );
      Print("KIRA receiver WebRequest failed. Terminal error: ", terminalError);
      return;
   }

   string body = CharArrayToString(result, 0, -1, CP_UTF8);
   string displayBody = ClipForTerminal(body, 1200);

   DisplayStatus(
      "Last check complete.\n"
      "HTTP: " + IntegerToString(responseCode) + "\n"
      "Received manual-review payload:\n"
      + displayBody
   );

   Print("KIRA receiver checked API. HTTP: ", responseCode, ". Manual review only.");
}
