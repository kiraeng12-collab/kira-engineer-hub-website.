//+------------------------------------------------------------------+
//| KIRA Copy Executor EA                                            |
//| Proprietary KIRA Engineer Hub material.                          |
//|                                                                  |
//| Member-side auto-copy executor. It polls the KIRA bridge for the |
//| member's pending copy commands and, when the MEMBER has opted in,|
//| places the trade on the MEMBER's own MT5 account.                |
//|                                                                  |
//| Design: KIRA's server never places orders. This EA runs on the   |
//| member's terminal and executes under the member's own settings.  |
//|                                                                  |
//| SAFETY DEFAULTS (all opt-in):                                     |
//|   - EnableOrderPlacement = false  -> dry-run, logs only.          |
//|   - AllowLiveAccount     = false  -> refuses REAL accounts.       |
//|   - CopyMode             = MANUAL -> never auto-places.           |
//| Test on a DEMO account first. Do not enable live until verified.  |
//+------------------------------------------------------------------+
#property copyright "KIRA Engineer Hub"
#property version   "1.0"
#property strict

#include <Trade/Trade.mqh>

enum ENUM_KIRA_COPY_MODE { KIRA_MANUAL = 0, KIRA_AUTO = 1 };
enum ENUM_KIRA_LOT_MODE  { KIRA_SAME = 0, KIRA_MULTIPLY = 1, KIRA_REDUCE = 2 };

input string             BridgeUrl            = "";                    // e.g. https://kira-bridge.onrender.com
input string             MemberId             = "";
input string             ActivationCode       = "";                    // your KIRA activation code
input string             BrokerAccountId      = "";                    // member broker account label
input string             TerminalInstanceId   = "mt5-executor-1";
input string             SigningSecret        = "";                   // set to the bridge COMMAND_SIGNING_SECRET to verify command integrity
input ENUM_KIRA_LOT_MODE LotMode              = KIRA_SAME;             // exact / multiply / reduce
input double             LotMultiplier        = 1.0;                   // used for MULTIPLY / REDUCE
input ENUM_KIRA_COPY_MODE CopyMode            = KIRA_MANUAL;           // AUTO = hands-free, MANUAL = log only
input bool               EnableOrderPlacement = false;                 // MASTER SWITCH: must be true to trade
input bool               AllowLiveAccount     = false;                 // must be true to trade a REAL account
input int                PollSeconds          = 5;
input long               MagicNumber          = 990201;
input int                MaxSlippagePoints    = 20;
input double             MaxLot               = 1.0;                    // hard per-trade lot cap
input string             SymbolSuffix         = "";                    // broker symbol suffix, e.g. ".m"

CTrade   trade;
string   executedIds[];   // in-session dedup of placed command ids

// Mapping of master position -> the local copy we opened, so we can mirror the
// owner's later SL/TP moves and closes onto the member's own trade.
string   mapMasterPos[];
string   mapTickets[];   // CSV of local position tickets (adds create extra tickets)
double   mapBaseVol[];   // member volume at ratio 1.0 (the master's opening size)
double   mapSl[];
double   mapTp[];

string   lastStatus = "Starting KIRA Copy Executor...";

//+------------------------------------------------------------------+
int OnInit()
{
   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(MaxSlippagePoints);
   EventSetTimer(MathMax(2, PollSeconds));
   ShowStatus("Standby. Executor loaded.");
   Print("KIRA Copy Executor loaded. OrderPlacement=", EnableOrderPlacement,
         " CopyMode=", (CopyMode == KIRA_AUTO ? "AUTO" : "MANUAL"),
         " AllowLive=", AllowLiveAccount);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason) { EventKillTimer(); Comment(""); }
void OnTick() { }

//+------------------------------------------------------------------+
void OnTimer()
{
   if(!IsConfigured()) { ShowStatus("Setup incomplete: add Bridge URL, Member ID, activation code, broker label."); return; }

   string body;
   int http = FetchPending(body);
   if(http == -1) { ShowStatus("WebRequest blocked. Add the Bridge URL in Tools > Options > Expert Advisors > Allow WebRequest."); return; }
   if(http != 200) { ShowStatus("Bridge HTTP " + IntegerToString(http)); return; }

   int placed = 0, reviewed = 0;
   string lines[];
   int n = StringSplit(body, '\n', lines);
   for(int i = 0; i < n; i++)
   {
      if(StringFind(lines[i], "COMMAND|") != 0) continue;
      reviewed++;
      if(HandleCommand(lines[i])) placed++;
   }

   int mirrored = ReconcilePositions();

   ShowStatus(StringFormat("Checked bridge. Commands: %d. Placed: %d. Mirrored (SL/TP/close): %d.\nMode: %s  Placement: %s  Account: %s",
      reviewed, placed, mirrored,
      (CopyMode == KIRA_AUTO ? "AUTO" : "MANUAL"),
      (EnableOrderPlacement ? "ENABLED" : "DRY-RUN"),
      (IsDemoAccount() ? "DEMO" : "REAL")));
}

//+------------------------------------------------------------------+
//| Mirror the master's SL/TP moves, adds, scale-outs and closes onto |
//| our local copies. Reconciles against live master state (idempotent|
//| self-healing). A master position may map to several local tickets |
//| (adds create new positions on hedging accounts).                  |
//+------------------------------------------------------------------+
int ReconcilePositions()
{
   if(!EnableOrderPlacement) return 0;                 // dry-run: nothing to mirror
   if(ArraySize(mapMasterPos) == 0) return 0;          // we have not opened any copies

   string body;
   if(FetchPositionActions(body) != 200) return 0;

   int changed = 0;
   string lines[];
   int n = StringSplit(body, '\n', lines);
   for(int i = 0; i < n; i++)
   {
      if(StringFind(lines[i], "POSITION|") != 0) continue;
      string masterPos = Field(lines[i], "id");
      int m = MapIndex(masterPos);
      if(m < 0) continue;                              // not a position we copied

      // Refresh live tickets and current total volume for this master position.
      ulong tickets[];
      int tc = ParseTickets(mapTickets[m], tickets);
      double currentTotal = 0;
      string psym = "";
      long ptype = -1;
      string liveCsv = "";
      for(int t = 0; t < tc; t++)
      {
         if(PositionSelectByTicket(tickets[t]))
         {
            currentTotal += PositionGetDouble(POSITION_VOLUME);
            psym = PositionGetString(POSITION_SYMBOL);
            ptype = PositionGetInteger(POSITION_TYPE);
            liveCsv = (StringLen(liveCsv) ? liveCsv + "," : "") + IntegerToString((long)tickets[t]);
         }
      }
      mapTickets[m] = liveCsv;
      if(StringLen(liveCsv) == 0) { ForgetMap(m); continue; }   // member already flat

      bool closed = (Field(lines[i], "closed") == "true");
      double newSl = StringToDouble(Field(lines[i], "sl"));
      double newTp = StringToDouble(Field(lines[i], "tp"));
      double ratio = StringToDouble(Field(lines[i], "frac"));   // current/open (>1 = added to)

      if(closed)
      {
         if(CloseTickets(liveCsv)) changed++;
         ForgetMap(m);
         continue;
      }

      // Mirror SL/TP moves across every ticket of this position.
      if(MathAbs(newSl - mapSl[m]) > _Point / 2 || MathAbs(newTp - mapTp[m]) > _Point / 2)
      {
         if(ModifyTickets(liveCsv, newSl, newTp)) { mapSl[m] = newSl; mapTp[m] = newTp; changed++; }
      }

      // Mirror volume: target = member's opening size * master's current ratio.
      double step   = SymbolInfoDouble(psym, SYMBOL_VOLUME_STEP); if(step <= 0) step = 0.01;
      double minVol = SymbolInfoDouble(psym, SYMBOL_VOLUME_MIN);
      double target = mapBaseVol[m] * ratio;
      double diff   = target - currentTotal;

      if(diff >= step - step / 1000.0)
      {
         // Owner ADDED to the position -> add the delta as a new local order.
         if(IsDemoAccount() || AllowLiveAccount)
         {
            double addAmt = NormalizeVolume(psym, diff);
            string side = (ptype == POSITION_TYPE_BUY) ? "BUY" : "SELL";
            bool ok = (side == "BUY")
               ? trade.Buy(addAmt, psym, 0.0, newSl, newTp, "KIRA add " + masterPos)
               : trade.Sell(addAmt, psym, 0.0, newSl, newTp, "KIRA add " + masterPos);
            if(ok)
            {
               mapTickets[m] = (StringLen(mapTickets[m]) ? mapTickets[m] + "," : "") + IntegerToString((long)trade.ResultOrder());
               Print("KIRA: added ", DoubleToString(addAmt,2), " to master pos ", masterPos, " -> target ", DoubleToString(target,2));
               changed++;
            }
         }
      }
      else if(-diff >= step - step / 1000.0)
      {
         // Owner SCALED OUT -> reduce our copies by the delta.
         double toClose = NormalizeDouble(MathFloor((-diff) / step + 1e-7) * step, 2);
         if(ReduceTickets(liveCsv, toClose, minVol, step)) changed++;
      }
   }
   return changed;
}

int FetchPositionActions(string &outBody)
{
   string url = BaseUrl()
      + "/v1/members/" + MemberId + "/position-actions?format=mt5-text"
      + "&brokerAccountId=" + BrokerAccountId
      + "&terminalInstanceId=" + TerminalInstanceId;
   string headers =
      "x-kira-member-id: " + MemberId + "\r\n" +
      "x-kira-broker-account-id: " + BrokerAccountId + "\r\n" +
      "x-kira-terminal-instance-id: " + TerminalInstanceId + "\r\n" +
      "x-kira-member-secret: " + ActivationCode + "\r\n";
   char data[], result[];
   string resHeaders;
   ResetLastError();
   int code = WebRequest("GET", url, headers, 5000, data, result, resHeaders);
   if(code == -1) return -1;
   outBody = CharArrayToString(result, 0, -1, CP_UTF8);
   return code;
}

//+------------------------------------------------------------------+
//| Handle one COMMAND line. Returns true if an order was placed.    |
//+------------------------------------------------------------------+
bool HandleCommand(string line)
{
   string id     = Field(line, "id");
   string symbol = Field(line, "symbol");
   string side   = Field(line, "side");
   double volume = StringToDouble(Field(line, "volume"));   // member's resolved copy lot
   double sl     = StringToDouble(Field(line, "sl"));
   string tpRaw  = Field(line, "tp");
   double tp     = FirstTakeProfit(tpRaw);

   if(id == "" || symbol == "" || (side != "BUY" && side != "SELL")) return false;
   if(AlreadyExecuted(id)) return false;

   // Integrity: when a signing secret is configured, every command must carry a
   // valid HMAC signature. Fail-closed — an unsigned/tampered command is ignored.
   if(StringLen(SigningSecret) > 0 && !VerifyLineSignature(line))
   {
      Print("KIRA: command signature invalid or missing - rejected ", id);
      return false;
   }

   // --- Safety gates (all must pass to place a real order) ---
   if(CopyMode != KIRA_AUTO)      { Print("KIRA: MANUAL mode - review ", symbol, " ", side, " ", DoubleToString(volume,2), " (not auto-placed)"); return false; }
   if(!EnableOrderPlacement)      { Print("KIRA DRY-RUN: would place ", side, " ", symbol, " ", DoubleToString(volume,2), " sl=", DoubleToString(sl,_Digits), " tp=", DoubleToString(tp,_Digits)); return false; }
   if(!IsDemoAccount() && !AllowLiveAccount) { Print("KIRA BLOCKED: REAL account and AllowLiveAccount=false. Not placing ", symbol); return false; }

   string brokerSymbol = symbol + SymbolSuffix;
   if(!SymbolSelect(brokerSymbol, true)) { Print("KIRA: symbol not found on broker: ", brokerSymbol); return false; }

   volume = NormalizeVolume(brokerSymbol, volume);
   if(volume <= 0) { Print("KIRA: volume normalized to 0 for ", brokerSymbol, "; skipping."); return false; }

   bool ok = false;
   if(side == "BUY")  ok = trade.Buy(volume, brokerSymbol, 0.0, sl, tp, "KIRA copy " + id);
   else               ok = trade.Sell(volume, brokerSymbol, 0.0, sl, tp, "KIRA copy " + id);

   if(!ok) { Print("KIRA: order failed ", brokerSymbol, " ret=", trade.ResultRetcode(), " ", trade.ResultRetcodeDescription()); return false; }

   ulong ticket = trade.ResultOrder();   // position ticket (hedging: == opening order)
   Print("KIRA: placed ", side, " ", brokerSymbol, " ", DoubleToString(volume,2), " ticket=", (long)ticket);
   RememberExecuted(id);
   RememberMap(Field(line, "masterPositionId"), ticket, sl, tp, volume);   // enables SL/TP + close + scale-out mirroring
   AckToBridge(id, ticket);   // marks the command accepted server-side (prevents re-fetch)
   return true;
}

//+------------------------------------------------------------------+
//| HTTP: fetch pending commands as mt5-text                         |
//+------------------------------------------------------------------+
int FetchPending(string &outBody)
{
   string url = BaseUrl()
      + "/v1/members/" + MemberId + "/copy-commands/pending?format=mt5-text"
      + "&brokerAccountId=" + BrokerAccountId
      + "&terminalInstanceId=" + TerminalInstanceId
      + "&lotMode=" + LotModeString()
      + "&lotMultiplier=" + DoubleToString(LotMultiplier, 2);

   string headers =
      "x-kira-member-id: " + MemberId + "\r\n" +
      "x-kira-broker-account-id: " + BrokerAccountId + "\r\n" +
      "x-kira-terminal-instance-id: " + TerminalInstanceId + "\r\n" +
      "x-kira-member-secret: " + ActivationCode + "\r\n" +
      "x-kira-lot-mode: " + LotModeString() + "\r\n" +
      "x-kira-lot-multiplier: " + DoubleToString(LotMultiplier, 2) + "\r\n" +
      "x-kira-copier-version: mt5-executor-1\r\n";

   char data[], result[];
   string resHeaders;
   ResetLastError();
   int code = WebRequest("GET", url, headers, 5000, data, result, resHeaders);
   if(code == -1) return -1;
   outBody = CharArrayToString(result, 0, -1, CP_UTF8);
   return code;
}

//+------------------------------------------------------------------+
//| HTTP: acknowledge execution (accept) so it leaves the queue      |
//+------------------------------------------------------------------+
void AckToBridge(string commandId, ulong ticket)
{
   string url = BaseUrl() + "/v1/members/" + MemberId + "/copy-commands/" + commandId + "/decision"
      + "?brokerAccountId=" + BrokerAccountId + "&terminalInstanceId=" + TerminalInstanceId;

   string headers =
      "Content-Type: application/json\r\n" +
      "x-kira-member-id: " + MemberId + "\r\n" +
      "x-kira-broker-account-id: " + BrokerAccountId + "\r\n" +
      "x-kira-terminal-instance-id: " + TerminalInstanceId + "\r\n" +
      "x-kira-member-secret: " + ActivationCode + "\r\n";

   string bodyStr = "{\"decision\":\"ACCEPT\",\"note\":\"KIRA executor ticket " + IntegerToString((long)ticket) + "\"}";
   char data[], result[];
   string resHeaders;
   int len = StringToCharArray(bodyStr, data, 0, WHOLE_ARRAY, CP_UTF8);
   if(len > 0) ArrayResize(data, len - 1); // drop null terminator
   ResetLastError();
   WebRequest("POST", url, headers, 5000, data, result, resHeaders);
}

//+------------------------------------------------------------------+
//| Helpers                                                          |
//+------------------------------------------------------------------+
bool IsConfigured()
{
   return StringLen(BridgeUrl) > 0 && StringLen(MemberId) > 0
      && StringLen(ActivationCode) > 0 && StringLen(BrokerAccountId) > 0;
}

//+------------------------------------------------------------------+
//| Command integrity: standard HMAC-SHA256 verification.            |
//| NOTE: verify a signed command matches on a DEMO terminal before  |
//| relying on this in production (MQL5 crypto cannot be unit-tested  |
//| outside MetaTrader). Fail-closed: a mismatch means no trade.      |
//+------------------------------------------------------------------+
int StrToBytes(string s, uchar &out[])
{
   int len = StringToCharArray(s, out, 0, WHOLE_ARRAY, CP_UTF8);
   if(len > 0) ArrayResize(out, len - 1); // drop null terminator
   return ArraySize(out);
}

void Sha256Bytes(const uchar &data[], uchar &out[])
{
   uchar key[];
   ResetLastError();
   CryptEncode(CRYPT_HASH_SHA256, data, key, out);
}

string BytesToHex(const uchar &b[])
{
   string s = "";
   for(int i = 0; i < ArraySize(b); i++) s += StringFormat("%02x", b[i]);
   return s;
}

string HmacSha256Hex(string keyStr, string msgStr)
{
   uchar key[]; int kl = StrToBytes(keyStr, key);
   uchar msg[]; int ml = StrToBytes(msgStr, msg);

   uchar k0[]; ArrayResize(k0, 64); ArrayInitialize(k0, 0);
   if(kl > 64)
   {
      uchar kh[]; Sha256Bytes(key, kh);
      for(int i = 0; i < ArraySize(kh) && i < 64; i++) k0[i] = kh[i];
   }
   else
   {
      for(int i = 0; i < kl && i < 64; i++) k0[i] = key[i];
   }

   uchar ipad[]; ArrayResize(ipad, 64 + ml);
   uchar opadKey[]; ArrayResize(opadKey, 64);
   for(int i = 0; i < 64; i++)
   {
      ipad[i]    = (uchar)(k0[i] ^ 0x36);
      opadKey[i] = (uchar)(k0[i] ^ 0x5c);
   }
   for(int i = 0; i < ml; i++) ipad[64 + i] = msg[i];

   uchar inner[]; Sha256Bytes(ipad, inner);
   uchar outerIn[]; ArrayResize(outerIn, 64 + ArraySize(inner));
   for(int i = 0; i < 64; i++) outerIn[i] = opadKey[i];
   for(int i = 0; i < ArraySize(inner); i++) outerIn[64 + i] = inner[i];

   uchar outer[]; Sha256Bytes(outerIn, outer);
   return BytesToHex(outer);
}

bool VerifyLineSignature(string fullLine)
{
   int last = -1, p = 0;
   while(true)
   {
      int f = StringFind(fullLine, "|sig=", p);
      if(f < 0) break;
      last = f; p = f + 1;
   }
   if(last < 0) return false; // no signature present

   string canonical = StringSubstr(fullLine, 0, last);
   string provided  = StringSubstr(fullLine, last + 5);
   StringTrimLeft(provided); StringTrimRight(provided);
   string expected = HmacSha256Hex(SigningSecret, canonical);
   return (StringCompare(provided, expected, false) == 0);
}

bool IsDemoAccount()
{
   long mode = AccountInfoInteger(ACCOUNT_TRADE_MODE);
   return (mode == ACCOUNT_TRADE_MODE_DEMO || mode == ACCOUNT_TRADE_MODE_CONTEST);
}

string BaseUrl()
{
   string u = BridgeUrl;
   int len = StringLen(u);
   if(len > 0 && StringSubstr(u, len - 1, 1) == "/") u = StringSubstr(u, 0, len - 1);
   return u;
}

string LotModeString()
{
   if(LotMode == KIRA_MULTIPLY) return "MULTIPLY";
   if(LotMode == KIRA_REDUCE)   return "REDUCE";
   return "SAME";
}

double NormalizeVolume(string symbol, double volume)
{
   double minV  = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN);
   double maxV  = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MAX);
   double step  = SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP);
   if(step <= 0) step = 0.01;
   double capped = MathMin(volume, MaxLot);
   double steps  = MathFloor(capped / step + 0.0000001);
   double v = steps * step;
   if(v < minV) v = minV;
   if(v > maxV) v = maxV;
   return NormalizeDouble(v, 2);
}

double FirstTakeProfit(string tpRaw)
{
   if(StringLen(tpRaw) == 0) return 0.0;
   string parts[];
   int c = StringSplit(tpRaw, ',', parts);
   if(c <= 0) return StringToDouble(tpRaw);
   return StringToDouble(parts[0]);
}

// Extract a "key=value" field from a pipe-delimited COMMAND line.
string Field(string line, string key)
{
   string parts[];
   int c = StringSplit(line, '|', parts);
   string prefix = key + "=";
   int plen = StringLen(prefix);
   for(int i = 0; i < c; i++)
   {
      if(StringFind(parts[i], prefix) == 0)
         return StringSubstr(parts[i], plen);
   }
   return "";
}

bool AlreadyExecuted(string id)
{
   for(int i = 0; i < ArraySize(executedIds); i++)
      if(executedIds[i] == id) return true;
   return false;
}

void RememberExecuted(string id)
{
   int n = ArraySize(executedIds);
   ArrayResize(executedIds, n + 1);
   executedIds[n] = id;
}

int MapIndex(string masterPos)
{
   for(int i = 0; i < ArraySize(mapMasterPos); i++)
      if(mapMasterPos[i] == masterPos) return i;
   return -1;
}

void RememberMap(string masterPos, ulong ticket, double sl, double tp, double baseVol)
{
   if(StringLen(masterPos) == 0) return;
   int idx = MapIndex(masterPos);
   if(idx >= 0)
   {
      // Already tracking this master position (e.g. a re-open) -> append the ticket.
      mapTickets[idx] = (StringLen(mapTickets[idx]) ? mapTickets[idx] + "," : "") + IntegerToString((long)ticket);
      return;
   }
   int n = ArraySize(mapMasterPos);
   ArrayResize(mapMasterPos, n + 1); ArrayResize(mapTickets, n + 1);
   ArrayResize(mapBaseVol, n + 1); ArrayResize(mapSl, n + 1); ArrayResize(mapTp, n + 1);
   mapMasterPos[n] = masterPos; mapTickets[n] = IntegerToString((long)ticket);
   mapBaseVol[n] = baseVol; mapSl[n] = sl; mapTp[n] = tp;
}

void ForgetMap(int idx)
{
   int n = ArraySize(mapMasterPos);
   if(idx < 0 || idx >= n) return;
   for(int i = idx; i < n - 1; i++)
   {
      mapMasterPos[i] = mapMasterPos[i + 1]; mapTickets[i] = mapTickets[i + 1];
      mapBaseVol[i] = mapBaseVol[i + 1]; mapSl[i] = mapSl[i + 1]; mapTp[i] = mapTp[i + 1];
   }
   ArrayResize(mapMasterPos, n - 1); ArrayResize(mapTickets, n - 1);
   ArrayResize(mapBaseVol, n - 1); ArrayResize(mapSl, n - 1); ArrayResize(mapTp, n - 1);
}

//+------------------------------------------------------------------+
//| Multi-ticket helpers                                             |
//+------------------------------------------------------------------+
int ParseTickets(string csv, ulong &out[])
{
   ArrayResize(out, 0);
   if(StringLen(csv) == 0) return 0;
   string parts[];
   int c = StringSplit(csv, ',', parts);
   for(int i = 0; i < c; i++)
   {
      if(StringLen(parts[i]) == 0) continue;
      int k = ArraySize(out);
      ArrayResize(out, k + 1);
      out[k] = (ulong)StringToInteger(parts[i]);
   }
   return ArraySize(out);
}

bool CloseTickets(string csv)
{
   ulong tickets[];
   int c = ParseTickets(csv, tickets);
   bool any = false;
   for(int i = 0; i < c; i++)
      if(PositionSelectByTicket(tickets[i]) && trade.PositionClose(tickets[i]))
      { Print("KIRA: closed copy ticket ", (long)tickets[i]); any = true; }
   return any;
}

bool ModifyTickets(string csv, double sl, double tp)
{
   ulong tickets[];
   int c = ParseTickets(csv, tickets);
   bool any = false;
   for(int i = 0; i < c; i++)
      if(PositionSelectByTicket(tickets[i]) && trade.PositionModify(tickets[i], sl, tp))
      { any = true; }
   if(any) Print("KIRA: mirrored SL/TP sl=", DoubleToString(sl,_Digits), " tp=", DoubleToString(tp,_Digits));
   return any;
}

// Close `amount` of volume across the given tickets (newest first).
bool ReduceTickets(string csv, double amount, double minVol, double step)
{
   ulong tickets[];
   int c = ParseTickets(csv, tickets);
   double remaining = amount;
   bool any = false;
   for(int i = c - 1; i >= 0 && remaining >= step - step / 1000.0; i--)
   {
      if(!PositionSelectByTicket(tickets[i])) continue;
      double vol = PositionGetDouble(POSITION_VOLUME);
      if(vol <= remaining + step / 1000.0)
      {
         if(trade.PositionClose(tickets[i])) { remaining -= vol; any = true; }
      }
      else
      {
         double closeAmt = NormalizeDouble(MathFloor(remaining / step + 1e-7) * step, 2);
         double leftover = vol - closeAmt;
         if(leftover < minVol) closeAmt = vol; // avoid leaving a sub-minimum remainder
         if(closeAmt >= vol - 1e-7)
         {
            if(trade.PositionClose(tickets[i])) { remaining -= vol; any = true; }
         }
         else if(closeAmt >= minVol - 1e-7 && trade.PositionClosePartial(tickets[i], closeAmt))
         {
            remaining -= closeAmt; any = true;
         }
      }
   }
   if(any) Print("KIRA: scaled out ", DoubleToString(amount,2));
   return any;
}

void ShowStatus(string message)
{
   lastStatus = message;
   Comment(
      "KIRA Copy Executor\n",
      "Member: ", MemberId, "   Account: ", BrokerAccountId, "\n",
      "Lot rule: ", LotModeString(), (LotMode == KIRA_SAME ? "" : " x" + DoubleToString(LotMultiplier,2)), "\n",
      "Order placement: ", (EnableOrderPlacement ? "ENABLED" : "DRY-RUN (safe)"),
      "   Live orders on REAL account: ", (AllowLiveAccount ? "ALLOWED" : "BLOCKED"), "\n\n",
      message
   );
}
