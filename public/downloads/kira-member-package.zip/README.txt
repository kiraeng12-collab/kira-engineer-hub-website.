KIRA Copier — start here
========================

This package connects your MetaTrader 5 to the KIRA copy-trading service.

In this package:
  - KIRA_Copy_Executor_EA        the copier you install in MT5
  - KIRA_Member_Manual_Receiver  optional: manual-review helper
  - SETUP-GUIDE.md               step-by-step setup (read this)
  - MEMBER-CONFIG-TEMPLATE.txt   fill in your details

Requirements:
  - MetaTrader 5 on Windows desktop or a Windows VPS (the mobile app cannot run it)
  - The Bridge URL, Member ID, and Access Key that KIRA gave you

Start on a DEMO account first. Then open SETUP-GUIDE.md and follow the steps.

Your Access Key is private and tied to your membership — do not share it.
KIRA never asks for your broker password.
