# KIRA Copier — Member Setup Guide

Welcome. This connects your MetaTrader 5 to the KIRA master account, so approved
trades copy to your own account — with your own broker and your own settings.
KIRA never sees your broker password.

---

## What you need

- **MetaTrader 5 on Windows desktop or a Windows VPS.**
  (The MT5 **mobile app cannot run copiers** — a phone-only setup won't work.
  A cheap Windows VPS runs it 24/7 without your PC on.)
- The **three values** KIRA gave you:
  - **Bridge URL** (e.g. `https://kira-bridge.onrender.com`)
  - **Member ID**
  - **Access Key** (looks like `KIRA-MEMBER-...`)
- Your MT5 logged in to **your own broker account**.

> **Start on a DEMO account.** Prove it works before using a real account.

---

## Step 1 — Install the copier

1. Open MetaTrader 5.
2. Open **MetaEditor** (the toolbar icon, or press F4).
3. Put `KIRA_Copy_Executor_EA` (the file in this package) into the **Experts** folder,
   then **Compile** it. (If you received a `.ex5` file, just copy it into
   `MQL5/Experts` — no compiling needed.)

## Step 2 — Allow the connection (one time)

In MT5: **Tools → Options → Expert Advisors → “Allow WebRequest for listed URL”**,
tick it, and add your **Bridge URL**. Click OK.

## Step 3 — Start it

1. Drag **KIRA Copy Executor** onto any chart.
2. In the inputs, set:
   - `BridgeUrl` — your Bridge URL
   - `MemberId` — your Member ID
   - `ActivationCode` — your Access Key
   - `BrokerAccountId` — a label for your account (e.g. `MY-MT5`)
   - `SigningSecret` — only if KIRA gave you one
3. Choose how you want to copy:
   - `CopyMode` = **AUTO** (hands-free) or **MANUAL** (you decide each trade)
   - `LotMode` = **Exact / Multiply / Reduce**, and `LotMultiplier` (e.g. 2 or 0.5)
4. **Demo first:** leave `AllowLiveAccount = false`. To actually place trades on a
   demo account, set `CopyMode = AUTO` and `EnableOrderPlacement = true`.
5. Turn on **Algo Trading** (the toolbar button). Done — the chart shows the status.

---

## What each mode does

- **AUTO** — approved master trades copy to your account automatically, using your
  lot rule. SL/TP moves, partial closes, adds, and closes are mirrored too.
- **MANUAL** — you review each trade first (with `EnableOrderPlacement = false` it
  only shows what it *would* do).

Your lot rule:
- **Exact** — same lot the master used.
- **Multiply** — master lot × your multiplier (e.g. ×2).
- **Reduce** — master lot × a fraction (e.g. ×0.5).

A built-in risk cap protects you: an oversized multiplier is trimmed to your limit.

---

## Going live (after demo works)

Only after copying works cleanly on demo, and on a real-account login:
set `AllowLiveAccount = true`. Start small and watch the first trades.

---

## Troubleshooting

- **“WebRequest not allowed”** → redo Step 2 (add the exact Bridge URL).
- **Nothing copies** → check Algo Trading is on; check `CopyMode = AUTO` and
  `EnableOrderPlacement = true`; check the Experts tab for `KIRA:` messages.
- **“command signature invalid”** → your `SigningSecret` doesn’t match KIRA’s — ask KIRA.
- **Access stopped working** → your subscription may have lapsed; renew with KIRA.

Questions? Contact KIRA. Do not share your Access Key — it is tied to your membership.
